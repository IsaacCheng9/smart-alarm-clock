# smart-alarm-clock
A smart alarm clock presented in a basic web interface, created using the
Flask module in Python. The user is able to read updated weather and news
information, receiving notifications if new weather or news information is
obtained. The user can also set alarms for the future (including alarms which
repeat every day), and cancel these alarms if they change their mind.